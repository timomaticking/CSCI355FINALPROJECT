const express = require('express');
const router = express.Router();
const fs = require("fs");
const path = require("path");
var crypto = require("crypto")
const mongoose = require ('mongoose')

const readUsers = () => {
    if (!fs.existsSync("./model/users.json")) return [];
    const data = fs.readFileSync("./model/users.json", 'utf8');
    return JSON.parse(data);
};

const writeUsers = (users) => {
    fs.writeFileSync("./model/users.json", JSON.stringify(users, null, 2));
};


let requizzle = "./model/revisedquizz.json"
const quizle = "./model/quizle.json";

const userDBFileName = "./model/userDB.json";


function readscores() {
    
    let scoro = fs.readFileSync("./model/scoress.json")
    return JSON.parse(scoro);
}

function writescores(users) {
    let data = JSON.stringify(users, null, 2);
    fs.writeFileSync("./model/scoress.json", data, "utf-8");
}

function readrevisedquizz() {
    let data = fs.readFileSync(requizzle, "utf-8");
    return JSON.parse(data);
}
function writerevisedquizz(users) {
    let data = JSON.stringify(users, null, 2);
    fs.writeFileSync(requizzle, data, "utf-8");

}

function readQuizle() {
    let data = fs.readFileSync(quizle, "utf-8");
    return JSON.parse(data);
}

function readUserDB() {
    let data = fs.readFileSync(userDBFileName, "utf-8");
    return JSON.parse(data);
}


function writeUserDB(users){
    let data = JSON.stringify(users, null, 2);
    fs.writeFileSync(userDBFileName, data, "utf-8");
    //make this so that users who type in login credentials that dont match are taken into sign up page
    
}

mongoose.connect("mongodb+srv://timoo:test12345@cluster0.coers.mongodb.net/finalproject")
const scoreschema = {
    Title: String,
    content: String
}
const Note = mongoose.model("Note", scoreschema);



router.get('/', (req, res) => {
    res.sendFile("/home/timothyng0169/csci355/Summer/csci355proj2/index.html")
  })

  router.post('/signup', (req, res) => {
    const { email, password } = req.body;
    console.log('Received signup data:', email, password); // Add this line

    if (!email || !password) {
        return res.status(400).send('Email and password are required.');
    }

    const users = readUsers();
    if (users.some((user) => user.email === email)) {
        return res.status(400).send('Email already exists.');
    }

    users.push({ email, password });
    writeUsers(users);

    res.status(201).send('Signup successful! You can now log in.');
});


const session = require('express-session');

// Add session middleware to your app (in app.js)

router.post('/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).send('Email and password are required.');
    }

    const users = readUsers();
    const user = users.find((user) => user.email === email && user.password === password);
    if (!user) {
        return res.status(401).send('Invalid email or password.');
    }


    let newbie = readUsers();
    newbie.push({ email, password });
    writeUsers(newbie);
 // Store user email in session
 //req.session.userEmail = email;

 res.redirect('/quiz');
});



router.get('/quiz', async(req, res) => {
    


    console.log("User request for quiz page");

   await quizgrab(req, res);

   /* const quizData = readQuizle();

    const shuffledQuestions = [...quizData].sort(() => Math.random() - 0.5);
    const selectedQuestions = shuffledQuestions.slice(0, 10);
    res.render('quiz', { questions: selectedQuestions });
    console.log(selectedQuestions);
    let userDB = readUserDB();
    userDB.push({ questions: selectedQuestions });
    writeUserDB(userDB);
    */
    const rq = readrevisedquizz();
    const sQ = [...rq].sort(() => Math.random() - 0.5);
    const readable = sQ.slice(0, 10);
    rq.splice[0, 9];
  //  console.log(readable);
    res.render('quiz', { questions: readable });
    let rep = readrevisedquizz();
    rep.push(readable[0]);
    rep.push(readable[1]);
    rep.push(readable[2]);
    rep.push(readable[3]);
    rep.push(readable[4]);
    rep.push(readable[5]);
    rep.push(readable[6]);
    rep.push(readable[7]);
    rep.push(readable[8]);
    rep.push(readable[9]);
    writerevisedquizz(rep);
    
    
});


async function quizgrab(req, res) {
    try {
        const response = await fetch(`https://opentdb.com/api.php?amount=10&type=boolean`);
        // console.log(response)
        const data = await response.json()
        //console.log(data)
        if (data && data.results && Array.isArray(data.results)) {
        
        
        
            let requizquestions = readrevisedquizz();
            requizquestions = [...requizquestions, ...data.results];
            // console.log(data);
            writerevisedquizz(requizquestions);
        
        } else {
            console.error('Invalid or nested results detected. Skipping this response.');
        }
    }
         catch (error) {
            console.error('Error fetching quiz data', error);
        }
    
    }


router.post('/submit-quiz', (req, res) => {
    const userAnswers = req.body;
   // console.log("User submitted answers:", userAnswers);
    let scorecount = 0;
    let reuserDB = readrevisedquizz();
    const lastQuiz = reuserDB.slice(reuserDB.length - 10, reuserDB.length);
   // console.log(lastQuiz);
    //const questions = lastQuiz.questions;
    console.log(lastQuiz);
    
    lastQuiz.forEach((question, index) => {
        const reuserAnswer = userAnswers[`question${index}`]; // User's answer
        const correctAnswer = question.correct_answer; // Correct answer from quizle.json

        if (reuserAnswer === correctAnswer) {
            scorecount++;
        }
    });

    console.log(`User scored ${scorecount}/10`);
   // res.render('result', { score: scorecount });
    // res.send(`You scored ${scorecount}/${questions.length}`);
    let newNote = new Note({
        title: "Cool check this out",
        content: `You got ${scorecount}0% on Open trivia my dood`
    }); newNote.save();
    let namook = readUsers();
    let scoree = readscores();
    const scorock = {
        "score": scorecount,
        "name": namook[namook.length - 1].email
    }
    scoree.push(scorock);
    writescores(scoree);
    res.render('result', { score: scorecount , playhistory: scoree});

    
})


router.post('/home-redirect', (req, res) => {
    res.sendFile("/home/timothyng0169/csci355/Summer/csci355proj2/index.html");
})

module.exports = router;

