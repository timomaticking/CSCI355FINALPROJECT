const express = require('express');
const app = express();
const path = require('path');
const fs = require ("fs");
const PORT = 2000;



const quizrouter = require('./routes/quizical');


//const userDBFileName = "./model/userDB.json";

app.use(express.static('.'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/', quizrouter);




//app.use('/' quizrouter);  

/*function readUserDB() {
    let data = fs.readFileSync(userDBFileName, "utf-8");
    return JSON.parse(data);
}

function writeUserDB(users){
    let data = JSON.stringify(users, null, 2);
    fs.writeFileSync(userDBFileName, data, "utf-8");
    //make this so that users who type in login credentials that dont match are taken into sign up page   
}

app.get('/quiz', (req, res) => {
    const quizData =JSON.parse (fs.readFileSync(path.join(__dirname, 'quiz.json'), 'utf-8'));

    const shuffledQuestions = [...quizData].sort(() => Math.random() - 0.5);
    const selectedQuestions = shuffledQuestions.slice(0, 10);
    res.render('quiz', { questions: selectedQuestions });
});
*/
app.listen(PORT, () => {
    console.log('Server is running on http://localhost:2000');
});




module.exports = app;